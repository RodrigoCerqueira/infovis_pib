library(dplyr)
library(lubridate)
library(RColorBrewer)
library(stringr)
library(tidyr)

#################################################################################################################################################################
################ Criando o dataset Wesley Cota
#################################################################################################################################################################


#Carregando dataset do Wesley Cota
dados_pais <- read.csv2("https://raw.githubusercontent.com/wcota/covid19br/master/cases-brazil-total.csv", sep=",")

#Salvando dataset do Wesley Cota
write.csv2(dados_pais,
           "C:\\Users\\Jonatas\\Google Drive\\SEI\\InfoVis\\InfoVisCovid19\\ETL_SBI\\Output\\WesleyCota.csv")

#################################################################################################################################################################
################ Criando o dataset por municipio
#################################################################################################################################################################

#################################################
# SBI por municípios
################################################
setwd("C:\\Users\\Jonatas\\Google Drive\\SEI\\InfoVis\\InfoVisCovid19\\ETL_SBI\\Input")

########### Leitura de dados do SBI-SESAB 
SBImunicipio <- read.csv2("exporta_boletim_epidemiologico_municipio_csv.csv", header = T , fileEncoding = "UTF-8", na.strings = "NA")

########## Transformando a variável casos.confirmados em numerica
SBImunicipio$Casos <- SBImunicipio$CASOS.CONFIRMADOS %>%
                             str_replace_all(fixed("."),"") %>%
                              as.numeric()

########## Extraindo Data do SBI por municipios
SBImunicipio$DATA <- SBImunicipio$DATA.INFORMATIVO %>%
                      str_sub(end = 10) %>%
                       dmy()

########## Extraindo Hora do SBI por municipios
SBImunicipio$HORA <- SBImunicipio$DATA.INFORMATIVO %>%
                      str_sub(star = -8)

########## Alterando nomes de algumas variaveis
SBImunicipio <- SBImunicipio %>%
                 rename(CD_GEOCMU6DIG=IBGE.MUNICIPIO) %>%
                  rename(DIAS_ULTIMO_CASO=DIAS.APOS.ULTIMO.CASO) 

########## Selecionando somente as variaveis de interesse
SBImunicipio <- SBImunicipio %>%
                 select("DATA","CD_GEOCMU6DIG",
                        "Casos")

########## Calculando dia mais recente dos dados
DiaMaisRecente <- max(SBImunicipio$DATA)

########## Filtrando somente a data mais recente
SBImunicipio <- SBImunicipio %>% filter(DATA==DiaMaisRecente)

#########################################################################
# Importando informacoes populacionais e de geolocalizacao dos municipios
#########################################################################

POPmunicipio <- read.csv("populacao_municipios.csv", sep=";", fileEncoding = "ISO-8859-1", dec=",") 
names(POPmunicipio)

#########################################################################
# SBI Obitos
#########################################################################

########### Leitura de dados do SBI-SESAB
SBIObitos <- read.csv2("exporta_obitos_individualizados_csv.csv", header = T , fileEncoding = "UTF-8", na.strings = "NA")
str(SBIObitos)
Tab_Obitos <- SBIObitos %>% 
               rename(CD_GEOCMU6DIG=IBGE.MUNICIPIO) %>%
                group_by(CD_GEOCMU6DIG) %>% summarise(Obitos=n())

#########################################################################
# Montando a base de dados de geolocalizacao com SBI municipios
#########################################################################

covid_BA_Municipios <- merge(POPmunicipio, SBImunicipio, by="CD_GEOCMU6DIG", all.x=T)
covid_BA_Municipios$Casos[is.na(covid_BA_Municipios$Casos)] <- 0
covid_BA_Municipios$DATA[is.na(covid_BA_Municipios$DATA)] <- DiaMaisRecente

#########################################################################
# juntando os obitos a base de dados
#########################################################################

covid_BA_Municipios <- merge(covid_BA_Municipios, Tab_Obitos, by="CD_GEOCMU6DIG", all.x=T)
covid_BA_Municipios$Obitos[is.na(covid_BA_Municipios$Obitos)] <- 0

#########################################################################
# criando variável categórica
#########################################################################

#########################################################################
# criando variável categórica
#########################################################################

covid_BA_Municipios <- covid_BA_Municipios %>%
                        mutate(Letalidade=round((Obitos/Casos*100),2)) %>% 
                         mutate(Prevalencia_casos=round((Casos/POP_MUN*100000),2))

covid_BA_Municipios$Letalidade[is.nan(covid_BA_Municipios$Letalidade)] <- NA

#########################################################################
# Exportando a base de dados por municipio
#########################################################################

write.csv2(covid_BA_Municipios,
           "C:\\Users\\Jonatas\\Google Drive\\SEI\\InfoVis\\InfoVisCovid19\\ETL_SBI\\Output\\covid_BA_Municipios.csv", 
           quote = F, row.names = FALSE)

#################################################################################################################################################################
################ Faixa Etaria Obito
#################################################################################################################################################################

# criando variável categórica
SBIObitos$FaixaEtaria <- cut(SBIObitos$IDADE, c(0,1,4,9,19,29,39,49,59,69,79,120),
                                     labels=c("< 1 ano",
                                              "01 a 04",
                                              "05 a 09",
                                              "10 a 19",
                                              "20 a 29",
                                              "30 a 39",
                                              "40 a 49",
                                              "50 a 59",
                                              "60 a 69",
                                              "70 a 79",
                                              "80 ou mais"),
                                 rigth=T,exclude=NULL, include.lowest=TRUE)

Tab_fxetariaObito <- SBIObitos %>% 
                  group_by(FaixaEtaria) %>% 
                   summarise(Obitos=n()) %>%
                    mutate(Percentual=round(Obitos/sum(Obitos)*100,2))

rotulos <- data.frame(FaixaEtaria=c("< 1 ano", "01 a 04", "05 a 09", "10 a 19", "20 a 29",
"30 a 39", "40 a 49", "50 a 59", "60 a 69", "70 a 79", "80 ou mais"))

fxetariaObito <- merge(rotulos, Tab_fxetariaObito, by="FaixaEtaria", all.x=T)
fxetariaObito$Obitos[is.na(fxetariaObito$Obitos)] <- 0
fxetariaObito$Percentual[is.na(fxetariaObito$Percentual)] <- 0

#########################################################################
# Exportando a base de dados Faixa Etaria dos Obitos
#########################################################################

write.csv2(fxetariaObito,
           "C:\\Users\\Jonatas\\Google Drive\\SEI\\InfoVis\\InfoVisCovid19\\ETL_SBI\\Output\\fxetariaObito.csv", 
           quote = F, row.names = FALSE)

#################################################################################################################################################################
################ SBI Consolidado
#################################################################################################################################################################


#################################################################################################################################################################
################ Faixa Etaria casos confirmados
#################################################################################################################################################################

########### Leitura de dados do SBI-Faixa Etaria
SBIFxEtaria <- read.csv2("exporta_boletim_faixa_etaria_csv.csv", header = F , fileEncoding = "UTF-8", na.strings = "NA")

########### Alterando o head do SBI Faixa Etaria
SBIFxEtaria <- SBIFxEtaria[,1:4]
names(SBIFxEtaria) <- c("Date","FaixaEtaria","Casos","Percentual")

########## Extraindo Data do SBI Faixa Etaria
SBIFxEtaria$DATA <- SBIFxEtaria$Date %>%
  str_sub(end = 10) %>%
  dmy()

########## Filtrando somente a data mais recente
SBIFxEtaria <- SBIFxEtaria %>% filter(DATA==max(SBIFxEtaria$DATA))

########## Selecionando somente as variaveis de interesse
fxetaria <- SBIFxEtaria %>%
                  select("FaixaEtaria",
                    "Casos","Percentual")


#fxetaria[fxetaria$FaixaEtaria=="< 1","FaixaEtaria"] <- as.factor("< 1 ano") 
#View(fxetaria)
#########################################################################
# Exportando a base de dados Faixa Etaria dos casos confirmados
#########################################################################

write.csv2(fxetaria,
           "C:\\Users\\Jonatas\\Google Drive\\SEI\\InfoVis\\InfoVisCovid19\\ETL_SBI\\Output\\fxetaria_.csv", 
           quote = F, row.names = FALSE)


#################################################################################################################################################################
################ Criando o dataset SBI Consolidado
#################################################################################################################################################################

#################################################
# SBI Consolidado
################################################

########### Leitura de dados do SBI-SESAB
SBIConsolidado <- read.csv2("exporta_boletim_epidemiologico_csv.csv", header = T , fileEncoding = "UTF-8", na.strings = "NA")
names(SBIConsolidado)

########## Extraindo Data do SBI por municipios
SBIConsolidado$DATA <- SBIConsolidado$DATA.DO.BOLETIM %>%
                        str_sub(end = 10) %>%
                        dmy()

########## Calculando dia mais recente dos dados
DiaRecente <- max(SBIConsolidado$DATA)

########## Filtrando somente a data mais recente
SBIConsolidado <- SBIConsolidado %>% filter(DATA==DiaRecente)

#################################################
# Sexo dos confirmados 
################################################

nmasc <- SBIConsolidado[,"CASOS.SEXO.MASCULINO"] %>%
          str_replace_all(fixed("."),"") %>%
          as.numeric()

nfemi <- SBIConsolidado[,"CASOS.SEXO.FEMININO"] %>%
  str_replace_all(fixed("."),"") %>%
  as.numeric()

sexo <- data.frame(Sexo=c("Feminino","Masculino"),Casos=c(nfemi,nmasc)) %>%
         mutate(Percentual=round(Casos/sum(Casos)*100,2))

#######################################################
# Exportando a base de dados Sexo dos casos confirmados
#######################################################

write.csv2(sexo,
           "C:\\Users\\Jonatas\\Google Drive\\SEI\\InfoVis\\InfoVisCovid19\\ETL_SBI\\Output\\sexo.csv", 
           quote = F, row.names = FALSE)


#################################################
# Situacao dos confirmados 
################################################

nobitos <- SBIConsolidado[,"TOTAL.OBITOS"] %>%
  str_replace_all(fixed("."),"") %>%
  as.numeric()

nrecuperados <- SBIConsolidado[,"CASOS.RECUPERADOS"] %>%
  str_replace_all(fixed("."),"") %>%
  as.numeric()

nisoladomi <- SBIConsolidado[,"CASOS.ISOLAMENTO.DOMICILIAR"] %>%
  str_replace_all(fixed("."),"") %>%
  as.numeric()

nenfermaria <- SBIConsolidado[,"CASOS.ENFERMARIA"] %>%
  str_replace_all(fixed("."),"") %>%
  as.numeric()

nuti <- SBIConsolidado[,"CASOS.UTI"] %>%
  str_replace_all(fixed("."),"") %>%
  as.numeric()


Confirmados <- data.frame(
                  sit=c("Óbitos","Curados", "Vírus ativo"),
                  Casos=c(nobitos,nrecuperados,(nisoladomi+nenfermaria+nuti))
                  ) %>%
                    mutate(Percentual=round(Casos/sum(Casos)*100,2))

#######################################################
# Exportando a base de dados Sexo dos casos confirmados
#######################################################

write.csv2(Confirmados,
           "C:\\Users\\Jonatas\\Google Drive\\SEI\\InfoVis\\InfoVisCovid19\\ETL_SBI\\Output\\Confirmados.csv", 
           quote = F, row.names = FALSE)


#######################################################
# COMORBIDADES - CARREGANDO/ AJUSTANDO/ SALVANDO
#######################################################

obitos_comorbidade <- read.csv2("exporta_obitos_individualizados_csv.csv", encoding = "UTF-8")

obitos_comorbidade <- obitos_comorbidade %>% 
  filter(COMORBIDADE == "S") %>%
    select(LISTA.COMORBIDADE) %>%
      rename(comorbidades="LISTA.COMORBIDADE") %>%
        mutate(comorbidades = strsplit(as.character(comorbidades), ",")) %>%
          unnest(comorbidades) %>%
            mutate(cont_comorbidade = 1) %>%
              group_by(comorbidades) %>%
                summarise(vitimas=sum(cont_comorbidade))

write.csv2(obitos_comorbidade, 
           "C:\\Users\\Jonatas\\Google Drive\\SEI\\InfoVis\\InfoVisCovid19\\ETL_SBI\\Output\\comorbidades.csv", row.names = F)










