# InfoVisCovid19
Dashboard with covid-19 data in Bahia-Brazil, created by SEIDataLab data scientists. 

Elaborated using the RStudio Shiny framework.

Hosted on a shiny server allocated at PRODEB - Government of Bahia.

<img src="infovis_gif.gif" />

Use the libraries: 

- <img src="http://hexb.in/hexagons/shiny.png" width="12.9" height="15" /> ``shiny`` 
- [X] ``shinydashboard`` 
- [X] ``shinydashboardPlus`` 
- [X] ``shinyWidgets`` 
- [X] ``dplyr`` 
- [X] ``DT`` 
- [X] ``ggplot2`` 
- [X] ``ggthemes`` 
- [X] ``ggiraph``
- [X] ``lubridate`` 
- [X] ``stringr`` 
- [X] ``jsonlite`` 
- [X] ``scales`` 
- [X] ``RColorBrewer`` 
- [X] ``leaflet`` 
- [X] ``rgdal``
- [X] ``sp``
