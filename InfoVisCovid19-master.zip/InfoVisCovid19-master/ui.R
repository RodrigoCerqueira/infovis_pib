################################################################################################### 
# SEIDataLab - Laboratorio de Dados da Superintendencia de Estudos Economicos e Sociais da Bahia
################################################################################################### 
#####   DESCRIÇÃO:        dashboard coronovirus do InfoVis
#####   DATA DA CRIAÇÃO:  23/03/2020
#####   ESCRITO POR:      Cleiton Rocha, Jackson Conceicao, Jonatas Silva, Kellyene Coleho, Rodrigo Cerqueira
#####   SITE:             https://infovis.sei.ba.gov.br/covid19
#####   LICENÇA:          GPLv3
#####   PROJETO:          https://github.com/SEIDataLab/InfoVisCovid19


#Carregando Pacote para fazer aplicativos shiny
library(shiny)
library(shinydashboard)
library(shinydashboardPlus)
library(shinyWidgets)
library(leaflet)
library(lubridate)
library(dplyr)
library(DT)
library(ggiraph)

hoje_data2 <- today("GMT") %>% format("%d/%m/%Y")
dia_atualiza <- "18-06-2020"
hora_atualiza <- "19h00m"
isola_atualiza <- "17-06-2020."

#ui
dashboardPagePlus(skin = "red", title="SEI - Covid19",
                  header = dashboardHeaderPlus(
                    title = tagList(
                      span(class = "logo-lg", img(src = "LogoGovBaTransp.png", width = "147.46px", height = "40px")), 
                      img(src = "SEI_transparente.png",
                          width = "30px", height = "30px")
                    )
                  ),
                  sidebar = dashboardSidebar(
                    sidebarMenu( 
                                menuItem("COVID-19 na Bahia", tabName = "aba1", icon = icon("capsules")),
                                menuItem("COVID-19 no Nordeste", tabName = "aba2", icon=icon("allergies")),
                                menuItem("COVID-19 no Brasil", tabName = "aba3", icon=icon("globe-americas")),
                                menuItem("COVID-19 em Salvador", tabName = "aba4", icon = icon("map-marker")),
                                menuItem("Leia-me", tabName = "aba5",icon = icon("file-alt"))
                                )
                  ),   
                  dashboardBody(
                    tags$head(
                    tags$link(rel="sortcut icon", href="LogoGovBa.png", type="image/png"),
                    tags$link(rel = "stylesheet", type = "text/css", href = "custom.css"), includeHTML("google-analytics.html")
                  ),
                    tabItems(
                      
                      
                      ################################################################################
                      # Covid na Bahia
                      #################################################################################
                      tabItem(tabName = "aba1",
                              p(paste("Última atualização: ", dia_atualiza, " às ", hora_atualiza,".")),
                              fluidRow(valueBoxOutput("CasesBahia", width=3),
                                       valueBoxOutput("TxPrevalenciaBA", width=3),
                                       valueBoxOutput("MorteBahia", width=3),
                                       valueBoxOutput("TxletalidadeBA", width=3)
                              ),  
                            ###########################################  
                              fluidRow(
                                column(width=6,
                                       box(
                                         width = NULL,
                                         title = paste("Situação Covid-19, Bahia."),
                                         status = "danger",
                                         ggiraphOutput("DonutsConfirmados"),
                                         footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB)"
                                       )
                                ),
                                
                                column(width=6,
                                     
                                       box(
                                          width = NULL,
                                          title = paste("Casos confirmados do Covid-19, Bahia."),
                                          status = "danger",
                                          ggiraphOutput("CasosCovidBaAcumulado"),
                                          footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB)"
                                       )

                                )
                              
                              ),
   #######################################################################################
                              fluidRow(
                                column(width=6,
                                       box(
                                         width = NULL,
                                         title = paste("Casos confirmados de Covid-19 por municípios, Bahia."),
                                         status = "danger",     
                                         leafletOutput("mapa_bahia", height = 500),
                                         footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB). 
                                                Nota: Os limites municipais apresentados neste pictograma foram generalizados. 
                                         Confira os limites oficiais em: https://arcg.is/1O9bmT."
                                       ) 
                                ),
                                column(width=6,
                                       box(
                                         width = NULL,
                                         title = paste("Informações de Covid-19 por municípios, Bahia."),
                                         status = "danger",     
                                         DTOutput("TabPorCidade"),style = "height:500px; overflow-y: scroll;overflow-x: scroll;",
                                         footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB) ; * Local de possível infecção ; **por 100 mil habitantes"
                                       )
                                )
                              ),
                              
                              ##################

                              fluidRow(
                                column(width=6,
                                       box(
                                         width = NULL,
                                         title = paste("Sexo dos Infectados por Covid-19, Bahia."),
                                         status = "danger",     
                                         plotOutput("genero_bahia"),
                                         footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB)"
                                       ) 
                                ),
                                column(width=6,
                                       box(
                                         width = NULL,
                                         title = paste("Faixa Etária dos Infectados por Covid-19, Bahia."),
                                         status = "danger",     
                                         plotOutput("FxEtaria_Bahia"),
                                         footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB)"
                                       )
                                )
                              ),
                              br(),
                              #################
                              
   
   fluidRow(
     column(width=6,
            
            box(
               width = NULL,
               title = paste("Índice de Isolamento Social, por municípios, ",isola_atualiza),
               status = "danger",     
               leafletOutput("mapa_isol", height = 500),
               footer="Fonte: InLoco. Nota 1: Não representa a população em sua totalidade. 
               Dados gerados pela plataforma InLoco, por meio da geolocalização de dispositivos 
               móveis, não sendo o Governo da Bahia responsável por essas informações. 
               Nota2: Os limites municipais apresentados neste pictograma foram generalizados. 
                      Confira os limites oficiais em: https://arcg.is/1O9bmT."
            )
            
     ),
     column(width=6,

            box(
               width = NULL,
               title = paste("Índice de Isolamento Social, Bahia."),
               status = "danger",
               ggiraphOutput("EvolucaoIsolamento"),
               footer="Fonte: InLoco. Não representa a população em sua totalidade. Dados gerados pela plataforma InLoco, por meio da geolocalização de dispositivos móveis, não sendo o Governo da Bahia responsável por essas informações."
            )
     )
   ),  
                              ##################
                              
                              fluidRow(
                                column(width=6,
                                       box(
                                         width = NULL,
                                         title = paste("Comorbidades dos óbitos por Covid-19*."),
                                         status = "danger",     
                                         plotOutput("comorbidades"),
                                         footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB); * Uma vítima pode apresentar mais de uma comorbidade; **A categoria OUTRAS contempla todas comorbidades com frequência abaixo de 5."
                                       ) 
                                ),
                                column(width=6,
                                       box(
                                         width = NULL,
                                         title = paste("Faixa Etária dos Óbitos por Covid-19, Bahia."),
                                         status = "danger",     
                                         plotOutput("FxEtaria_Obitos"),
                                         footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB)"
                                       )
                                )
                              ),
   
   ###################################################################
   fluidRow(
      column(width=6,
             box(
                width = NULL,
                title = paste("Leitos Exclusivos Covid-19, por município, Bahia."),
                status = "danger",     
                leafletOutput("mapa_leitos", height = 470),
                footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB). 
                Nota: Confira os limites municipais oficiais em: https://arcg.is/1O9bmT."
             )
               ),
      column(width=6,
             box(
                width = NULL,
               title = paste("Situação dos Leitos exclusivos Covid-19, Bahia."),
                status = "danger",
                ggiraphOutput("LeitosBA", height = 470),
                footer="Fonte: Secretaria Estadual de Saúde do Estado da Bahia(SESAB)"
             )
     )
   ),  
   ####################################################################
                              
                      ),
                      
                      ################################################################################
                      # Covid no NE
                      #################################################################################
                      tabItem(tabName = "aba2",
                              fluidRow(valueBoxOutput("CasesNE", width=3),
                                       valueBoxOutput("TxPrevalenciaNE", width=3),
                                       valueBoxOutput("MorteNE", width=3),
                                       valueBoxOutput("TxletalidadeNE", width=3)
                              ),
                              
                      fluidRow(
                        column(width=6,
                               box(
                                 width = NULL,
                                 title = paste("Casos confirmados de Covid-19 por Estados, Nordeste do Brasil,", dia_atualiza),
                                 status = "danger",     
                                 leafletOutput("mapa_NE", height = 470),
                                 footer="Fonte: Secretarias estaduais de saúde e Ministério da Saúde. Dados sistematizados por:https://labs.wesleycota.com/sarscov2/br/"
                               ) 
                        ),
                        column(width=6,
                               box(
                                 width = NULL,
                                 title = paste("Informações de Covid-19 por Estado, Nordeste do Brasil,", dia_atualiza),
                                 status = "danger",     
                                 DTOutput("TabPorEstadoNE", height = 470),
                                 footer="Fonte: Secretarias estaduais de saúde e Ministério da Saúde. Dados sistematizados por:https://labs.wesleycota.com/sarscov2/br/ ; **por 100 mil habitantes"
                               )
                        )
                      ),
                      
                  ),
                      

                      ################################################################################
                      # Covid no Brasil
                      #################################################################################
                      tabItem(tabName = "aba3",
                              fluidRow(valueBoxOutput("CasesBrasil2", width=3), 
                                       valueBoxOutput("TxPrevalenciaBR", width=3),
                                       valueBoxOutput("MorteBrasil", width=3),
                                       valueBoxOutput("TxletalidadeBR", width=3)
                                       ),br(),
                              

                      fluidRow(
                        column(width=6,
                               box(
                                 width = NULL,
                                 title = paste("Casos confirmados de Covid-19 por Estados,", dia_atualiza),
                                 status = "danger",     
                                 leafletOutput("mapa_br", height = 500),
                                 footer="Fonte: Secretarias estaduais de saúde e Ministério da Saúde. Dados sistematizados por:https://labs.wesleycota.com/sarscov2/br/"
                               ) 
                        ),
                        column(width=6,
                               box(
                                 width = NULL,
                                 title = paste("Informações de Covid-19 por Estado,", dia_atualiza),
                                 status = "danger",     
                                 DTOutput("TabPorEstado"),style = "height:500px; overflow-y: scroll;overflow-x: scroll;",
                                 footer="Fonte: Secretarias estaduais de saúde e Ministério da Saúde. Dados sistematizados por:https://labs.wesleycota.com/sarscov2/br/  ; **por 100 mil habitantes"
                               )
                        )
                      ),
                      
                   ),
                      
                  ################################################################################
                  # Covid em SSA
                  #################################################################################
                  
                  
                  tabItem(tabName = "aba4",
                          fluidRow(valueBoxOutput("CasesSSA", width=4),
                                   valueBoxOutput("PctSsaBa", width=4),
                                   valueBoxOutput("PctBairrosSsa", width=4)
                          ),
                          
                          fluidRow(
                            column(width=6,
                                   box(
                                     width = NULL,
                                     title = paste("Casos confirmados de Covid-19 por bairro*** de Salvador,", "17-06-2020"),
                                     status = "danger",     
                                     leafletOutput("mapa_ssa", height = 470),
                                     footer="Fonte: Secretário de Saúde de Salvador. ; 
                                     *** Alguns casos ainda em investigação do bairro.
                                     Os limites municipais apresentados neste cartograma foram generalizados. 
                                     Confira os limites oficiais em: https://arcg.is/1O9bmT."
                                   ) 
                            ),
                            column(width=6,
                                   box(
                                     width = NULL,
                                     title = paste("Informações de Covid-19 por bairro de Salvador,", "17-06-2020"),
                                     status = "danger",     
                                     DTOutput("TabPorbairro", height = 470),style = "height:500px; overflow-y: scroll;overflow-x: scroll;",
                                     footer="Secretário de Saúde de Salvador."
                                   )
                            )
                          )
                          
                  ),
                  
                      ################################################################################
                      #Pagina de metadados
                      #################################################################################
                      tabItem(tabName = "aba5" ,
                              flipBox(
                                id = 1,
                                main_img = "SeiDataLab3.png",
                                #header_img = "",
                                front_title = "Sobre o Dashboard",
                                back_title = "Fonte dos dados",
                                front_btn_text = "saiba mais", back_btn_text = "voltar",
                                p("Disponível e atualizado diariamente desde 23 de março de 2020."),
                                p("Este Dashboard foi elaborado com o software R, através das bibliotecas Shiny."),
                                #p("Os dados de países são obtidos por meio da Johns Hopkins University Center for Systems Science and Engineering (JHU CSSE)."),
                                p("As informações detalhas de COVID-19 na Bahia, são fornecidas pela Secretaria de Saúde do Estado da Bahia (SESAB)."),
                                p("Os dados dos estados brasileiros (exceto da Bahia) são originados das Secretarias Estaduais de Saúde, sistematizado por https://labs.wesleycota.com/sarscov2/br/"),
                                p("Cálculo da prevalência: (nº infectados) / (população) x 100.000."),
                                p("Cálculo da letalidade: (nº mortos) / (nº infectados) x 100%."),
                                back_content = tagList(
                                  #p("Fonte do dataset de casos por país: dados da Johns Hopkins CSSE e sistematizados por Worldometer.info", tags$a(href="https://www.worldometers.info/coronavirus/", "https://www.worldometers.info/coronavirus/")),
                                  p("Secretaria de Saúde da Bahia:", tags$a(href="http://saude.ba.gov.br/", "http://www.saude.ba.gov.br/")),
                                  p("Fonte de dados dos outros Estados:", tags$a(href="https://labs.wesleycota.com/sarscov2/br/", "https://labs.wesleycota.com/sarscov2/br/")),
                                  #p("Painel de acompanhamento de COVID-19 do Cidacs:", tags$a(href="http://painel.covid19br.org/", "http://painel.covid19br.org/")),
                                  #p("Modelo de predição de novos casos de COVID-19 do Cidacs:", 
                                  #  tags$a(href="https://cidacslab.github.io/Mathematical-and-Statistical-Modeling-of-COVID19-in-Brazil/",
                                  #         "https://cidacslab.github.io/Mathematical-and-Statistical-Modeling-of-COVID19-in-Brazil/"))
                                  )))
                  ),
                  ########### rodape - inicio
                  
                  hr(),
   p("IMPORTANTE! Ressaltamos que os números são dinâmicos e, na medida em que as investigações clínicas e epidemiológicas avançam, os casos são reavaliados, sendo passíveis de reenquadramento na sua classificação"),
                  fluidRow(
                    column(width=5,
                           align="center",
                           a(href="http://seplan.ba.gov.br", target="_blank",
                             img(class="align-middle", src = "Seplancol.png",width = "351px", height = "100px")
                           )
                    ),
                    column(width=4,
                           align="center",
                           a(href="http://sei.ba.gov.br", target="_blank",
                             img(class="align-middle", src = "sei.png",width = "201.33px", height = "100px")
                           )
                    ),
                    column(width=3,
                           align="center",
                           a(href="http://sei.ba.gov.br", target="_blank",
                             img(class="align-middle", src = "SeiDataLab.png",width = "225.35px", height = "100px")
                           )
                    )
                    )
                  
                  ########### rodape - final
                )		
             )