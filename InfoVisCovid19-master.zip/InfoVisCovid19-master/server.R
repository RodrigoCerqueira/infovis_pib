################################################################################################### 
# SEIDataLab - Laboratorio de Dados da Superintendencia de Estudos Economicos e Sociais da Bahia
################################################################################################### 
#####   DESCRIÇÃO:        dashboard coronovirus do InfoVis
#####   DATA DA CRIAÇÃO:  23/03/2020
#####   ESCRITO POR:      Cleiton Rocha, Jackson Conceicao, Jonatas Silva, Kellyene Coleho, Rodrigo Cerqueira
#####   SITE:             https://infovis.sei.ba.gov.br/covid19
#####   LICENÇA:          GPLv3
#####   PROJETO:          https://github.com/SEIDataLab/InfoVisCovid19

library(shiny)
library(shinydashboard)
library(shinydashboardPlus)
library(shinyWidgets)
library(dplyr)
library(ggplot2)
library(ggthemes)
library(lubridate)
library(leaflet)
library(RColorBrewer)
library(jsonlite)
library(scales)
library(stringr)
library(rgdal)
library(DT)
library(ggiraph)
library(sp)

#################################################################################################################################################################
################ prepando dados da Bahia
#################################################################################################################################################################

########### Dados Situacao Casos confirmados

sitconf <- read.csv2("Confirmados.csv",fileEncoding = "ISO-8859-1", dec = ",")
sitconf$fraction = sitconf$Casos / sum(sitconf$Casos)
sitconf$ymax = cumsum(sitconf$fraction)
sitconf$ymin = c(0, head(sitconf$ymax, n=-1))
sitconf$media = (sitconf$ymax + sitconf$ymin)/2
sitconf$fraction = paste0(round(sitconf$fraction*100,1), "%") 

########### Dados isolamento Social
IsolaBA <- read.csv("IsolamentoBahia.csv", dec = ",", sep=";")
IsolaBA$isolated <- as.numeric(round(IsolaBA$isolated*100,2))
#names(IsolaBA)[1] <- "date"
IsolaBA$date <- as.Date(IsolaBA$date,format = "%d/%m/%y")

###############################################################################################
###############################################################################################
###############################################################################################

####### dataset com Isolamento dos municípios
isolamento <- read.csv2("Isolamento_Municípios.csv", encoding = "UTF-8")
names(isolamento)[1] <- "MUNICIPIO"

isolamento$Isolated_city <- str_replace(isolamento$Isolated_city, "%", "")
isolamento$Isolated_city <- as.numeric(str_replace(isolamento$Isolated_city, ",", "."))

# convertendo para formato data
isolamento$Dt <- dmy(isolamento$Dt)

# renomeando coluna para nome do json
#isolamento <- isolamento %>% rename(MUNICIPIO=X.U.FEFF.City.Name)
#isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Itaetê", "Itaeté")
isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Ibirapuã", "Ibirapoã")
isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Lagedo do Tabocal", "Lajedo do Tabocal")
isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Iuiú", "Iuiu")
isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Santa Teresinha", "Santa Terezinha")
isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Muquém de São Francisco", "Muquém do São Francisco")
isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Pau Brasil", "Pau-Brasil")
isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Lafaiete Coutinho", "Lafayette Coutinho")
isolamento$MUNICIPIO <- str_replace(isolamento$MUNICIPIO,"Lafaiete Coutinho", "Lafayette Coutinho")

# excluindo a variável de municipio com nome errado
isolamento <- isolamento %>% 
               select("Dt", "Isolated_city",  "MUNICIPIO")

# filtrando a data mais recente
isolamentorecente <- isolamento %>% filter(Dt == max(Dt))

###############################################################################################
###############################################################################################
###############################################################################################

#### Leitos bahia
LeitosBA <- read.csv2("TermometroLeitos.csv",fileEncoding = "ISO-8859-1", dec = ",")

#### dataset comorbidade
comorbidades_dt <- read.csv2("comorbidades.csv",fileEncoding = "ISO-8859-1", dec = ",")

#### DataSet Bahia por sexo
covid_BA_Sexo <- read.csv("sexo.csv", sep=";", dec=",") %>%
                  cbind(yposicao_legenda=c(24.15,74.15))

#### DataSet Bahia por Faixa Etaria
covid_BA_FxEtaria <- read.csv("fxetaria.csv", sep=";", dec=",")

#### DataSet Bahia por Faixa Etaria
Obitos_FxEtaria <- read.csv("fxetariaObito.csv", sep=";", dec=",")

# legenda do eixo X
legenda_fxaetaria <- c("< 1","01-04","05-09","10-19",
                       "20-29","30-39","40-49","50-59","60-69","70-79",
                       "+80","Ignorado")
                   
######## dataset Bahia
covid_BA <- read.csv("covid_BA_Municipios.csv", sep=";", fileEncoding = "ISO-8859-1", dec=",")

######## mapa BAHIA
mapa_ba <- rgdal::readOGR(dsn=getwd(), layer="DPA_A_GEN_2019_05_14_GCS_SIR_SEI", encoding = "ISO-8859-1")

# renomeando codigo do municipio
mapa_ba@data <- mapa_ba@data %>% rename(CD_GEOCMU=Codigo)

# transformando factor em num na shapefile
mapa_ba@data[["CD_GEOCMU"]] <- as.numeric(as.character((mapa_ba@data[["CD_GEOCMU"]])))

#merge
covid_map <- merge(mapa_ba,
                   (covid_BA %>% filter(CD_GEOCMU!=9999989) %>% filter(CD_GEOCMU!=9999999)), 
                   by="CD_GEOCMU") 

#View(covid_map@data)

covid_map@data$fxa_covid <- cut(covid_map@data$Casos, c(0,0.1,10,50,100,500,1000,100000), 
                           labels=c("Sem Casos",
                                    "1 a 10",
                                    "10 a 50",
                                    "50 a 100",
                                    "100 a 500",
                                    "500 a 1000",
                                    "mais de 1000"),
                           rigth=T,exclude=NULL, include.lowest=TRUE)


wardpal_mun <- colorFactor(c("#ffffff","#fee391", "#fec44f","#fe9929","#ec7014","#8c2d04","#461602"),
                           domain=factor(covid_map$fxa_covid, 
                                         levels=c("Sem Casos",
                                                  "1 a 10",
                                                  "10 a 50",
                                                  "50 a 100",
                                                  "100 a 500",
                                                  "500 a 1000",
                                                  "mais de 1000")))

################### juntando o índice de isolamento social ao mapa

########  merge
covid_map <- merge(covid_map, isolamentorecente, by="MUNICIPIO", all.x=T)

#isolamento muncipio
covid_map$fxa_isolamento <- cut(covid_map$Isolated_city, c(0,0.1,20,30,40,50,60,70,80,100),
                                labels=c("Sem Informação",
                                         "0% a 20%",
                                         "20% a 30%",
                                         "30% a 40%",
                                         "40% a 50%",
                                         "50% a 60%",
                                         "60% a 70%",
                                         "70% a 80%",
                                         "mais de 80%"),
                                rigth=T,exclude=NULL, include.lowest=TRUE)


# criando categorica
wardpal_isola <- colorFactor(c("white","#d73027", "#f46d43","#fdae61","#fee08b","#d9ef8b","#a6d96a", "#66bd63", "#1a9850"),
                             domain=factor(covid_map$fxa_isolamento, 
                                           levels=c("Sem Informação",
                                                    "0% a 20%",
                                                    "20% a 30%",
                                                    "30% a 40%",
                                                    "40% a 50%",
                                                    "50% a 60%",
                                                    "60% a 70%",
                                                    "70% a 80%",
                                                    "mais de 80%")), na.color = "white")


########################################################
################ Mapa Leitos
########################################################

LeitosReferencia <- read.csv2("Und_Referencia_Retaguarda_Covid_BA.csv",fileEncoding = "ISO-8859-1", dec = ",")

# remover hospitais sem leitos
LeitosReferencia <- LeitosReferencia %>%
                     mutate(hosp_zeroleitos=LeitosClinicos_DISPONIVEIS+
                                            LeitosPed_DISPONIVEIS + 
                                            Leitos_Adulto_UTI_DISPONIVEIS +
                                            Leitos_Ped_UTI_DISPONIVEIS) %>% 
                        filter(hosp_zeroleitos!=0)

#################################################################################################################################################################
################ Série Histórica Bahia
#################################################################################################################################################################

covid_BA_serie <- read.csv2("serie_casos_BA.csv") %>%
  mutate(date=as.Date(date,format("%d/%m/%Y")),
         casos=as.numeric(casos),
         casos_novos=as.numeric(casos_novos)) 

#################################################################################################################################################################
################ Value Box Bahia
#################################################################################################################################################################

Total_Bahia <-  covid_BA_serie %>% 
                 filter(date == max(date)) %>%
                  select(casos) %>%
                   as.numeric() #23463

tx_prev_ba <- (Total_Bahia/14873064)*100000

mortes_ba <- covid_BA %>% 
              summarise(total_mortos= sum(Obitos))%>%
               as.numeric() #790

tx_let_ba <- (mortes_ba / Total_Bahia) * 100


#################################################################################################################################################################
################ Medidas para Tabela
#################################################################################################################################################################

#Filtrando somente os municipis com casos confirmados
covid_BA_cases <- covid_BA %>% 
                   filter(Casos != 0) %>% 
                    select(NM_MUNICIP,Casos, Prevalencia_casos, Obitos, Letalidade)

# Ajustando formato decimal e acrescentado simbolo "%" na coluna letalidade

covid_BA_cases$Letalidade <- paste0(format(round(covid_BA_cases$Letalidade,2),
                                           nsmall=2,big.mark=".", decimal.mark=","),"%")

# ordenando por total de casos
covid_BA_cases <- covid_BA_cases[with(covid_BA_cases, order(-Casos)), ]

#################################################################################################################################################################
################ prepando dados da Brasi
#################################################################################################################################################################

#Carregando dataset do Wesley Cota
dados_pais <- read.csv2("https://raw.githubusercontent.com/wcota/covid19br/master/cases-brazil-total.csv", sep=",")
#dados_pais <- read.csv2("WesleyCota.csv.csv", sep=";")


#### Retirando a linha TOTAL
dados_pais <- dados_pais[dados_pais$state!="TOTAL", ]

# criando coluna com nome dos estados
dados_pais$NM_ESTADO <- recode(dados_pais$state, AC="ACRE",	AL="ALAGOAS", AP="AMAPÁ", AM="AMAZONAS",
                               BA="BAHIA", CE="CEARÁ",DF="DISTRITO FEDERAL",ES="ESPÍRITO SANTO",
                               GO="GOIÁS", MA="MARANHÃO", PA="PARÁ", PE="PERNAMBUCO", PI="PIAUÍ",
                               RO="RONDÔNIA", RR="RORAIMA", SC="SANTA CATARINA", SP="SÃO PAULO",
                               RN="RIO GRANDE DO NORTE", PR="PARANÁ", RS="RIO GRANDE DO SUL", MT="MATO GROSSO",
                               MS="MATO GROSSO DO SUL", MG="MINAS GERAIS", RJ="RIO DE JANEIRO", SE="SERGIPE",
                               TO="TOCANTINS", PB="PARAÍBA")

#Imputando dados da Bahia pelos dados da SESAB
dados_pais$totalCases[dados_pais$state=="BA"] <- Total_Bahia
dados_pais$deaths [dados_pais$state=="BA"] <- mortes_ba
dados_pais$newCases [dados_pais$state=="BA"] <- covid_BA_serie[max(nrow(covid_BA_serie)),"casos_novos"]

# dataset com pop 
pop_estados <- read.csv2("populacao_estados.csv", fileEncoding = "ISO-8859-1")

# agrupando
dados_pais <- full_join(dados_pais, pop_estados, by= "state")

# criando coluna 'Letalidade'
dados_pais <- dados_pais %>% mutate(Letalidade=(deaths/totalCases)*100)

# criando coluna 'prevalencia por 100 mil habitantes'
dados_pais <- dados_pais %>% mutate(Prevalencia=(totalCases/populacao)*100000)

########################################
#### Preparando dados para mapa por UF
########################################

# criando variável categórica
dados_pais$categorica <- cut(dados_pais$totalCases, c(0,5000,10000,20000,30000,40000,50000,1000000), 
                             labels=c(  "menos de 5000",
                                        "5000 a 10000",
                                        "10000 a 20000",
                                        "20000 a 30000",
                                        "30000 a 40000",
                                        "40000 a 50000",
                                        "mais de 50000"),
                             rigth=T)


#paleta 
wardpal2 <- colorFactor(brewer.pal(7, "YlOrBr"),domain=factor(dados_pais$categorica, levels=c( "menos de 5000",
                                                                                               "5000 a 10000",
                                                                                               "10000 a 20000",
                                                                                               "20000 a 30000",
                                                                                               "30000 a 40000",
                                                                                               "40000 a 50000",
                                                                                               "mais de 50000")))
#carregando a shape
mapa_uf <- rgdal::readOGR("BRUFE250GC_SIR.json", use_iconv = T, encoding = "UTF-8")
  
# juntando dataset e shape
covid_uf <- merge(mapa_uf, dados_pais, by="NM_ESTADO")

############################
#### Tabela de dados por UF
############################

# dataset com colunas utilizadas na tabela
covid_estados <- dados_pais %>% select(estado, totalCases, Prevalencia, deaths, Letalidade)

# Ajustando formato decimal e acrescentado simbolo "%" na coluna letalidade
covid_estados$Letalidade <- paste0(format(round(covid_estados$Letalidade,2),
                                       nsmall=2,big.mark=".", decimal.mark=","),"%")

# colocando em ordem decrescente 
covid_estados <- covid_estados[with(covid_estados, order(-totalCases)), ]

#################################################################################################################################################################
################ Value Box Brasil
#################################################################################################################################################################

numero_casos_br <- dados_pais %>% filter(state!="TOTAL") %>% select(totalCases) %>% summarise(sum(totalCases))

numero_mortes_br <- dados_pais %>% filter(state!="TOTAL") %>% select(deaths) %>% summarise(sum(deaths))

tx_prev_br <- (numero_casos_br/210147125)*100000

tx_let_br <- (numero_mortes_br / numero_casos_br) * 100

#################################################################################################################################################################
################ Preparando dados Nordeste
#################################################################################################################################################################

SiglasUFNordeste <- c("AL","BA","CE",
                     "MA","PB","PE",
                     "PI" ,"RN","SE")

dados_Nordeste <- dados_pais %>% filter(state %in% SiglasUFNordeste)

#carregando a shape
mapa_NE <- rgdal::readOGR("Nordeste_SIR.json", use_iconv = T, encoding = "UTF-8")

# juntando dataset e shape
covid_NE <- merge(mapa_NE, dados_Nordeste, by="NM_ESTADO")

# tabela com estados do NE
covid_nordeste <- covid_estados %>% filter(estado %in% c("Alagoas","Bahia","Ceará","Pernambuco","Maranhão",
                                                         "Paraíba","Rio Grande do Norte","Sergipe","Piauí"))


# ordenando por total de casos
covid_nordeste <- covid_nordeste[with(covid_nordeste, order(-totalCases)), ]


#################################################################################################################################################################
################ Value Box Nordeste
#################################################################################################################################################################


mortes_NE <- sum(covid_nordeste$deaths)

tx_prev_NE <- (sum(covid_nordeste$totalCases)/57071654)*100000

numero_casos_NE <- sum(covid_nordeste$totalCases)

tx_let_NE <- (sum(covid_nordeste$deaths) / sum(covid_nordeste$totalCases)) * 100

#################################################################################################################################################################
################ Aba Salvador
#################################################################################################################################################################

# shape
#mapa_ssa <- rgdal::readOGR("ssa_bairros.json", use_iconv = T, encoding = "UTF-8")
mapa_ssa <- rgdal::readOGR("Bairros_Salvador.json", use_iconv = T, encoding = "UTF-8")

# casos
dados_SSA <- read.csv2("CovidBairrosSSA.csv", fileEncoding = "ISO-8859-1")

# renomeando colunas
dados_SSA <- dados_SSA %>% rename(id="Bairro")
mapa_ssa@data <- mapa_ssa@data %>% rename(id="nome")

# ajustando nome de bairro
#mapa_ssa@data$id <- recode(mapa_ssa@data$id, "Campinas de Prajá"="Campinas de Pirajá")
#dados_SSA$id <- recode(dados_SSA$id, "Vila Ruy Barbosa/Jardim Cruzeiro"="Jardim Cruzeiro/Vila Ruy Barbosa")                               

# merge
covid_BAIRROS_SSA <- merge(mapa_ssa,dados_SSA[dados_SSA$id!="Em investigação",], by="id" ) 

# transformando NA em 0
#covid_BAIRROS_SSA$total[is.na(covid_BAIRROS_SSA$total)] <- 0

# criando variável categórica
covid_BAIRROS_SSA$fxa_covidbairro <- cut(covid_BAIRROS_SSA$total, c(0,0.1,30,50,100,200,300,1000), 
                                         labels=c("Sem Casos",
                                                  "1 a 30",
                                                  "31 a 50",
                                                  "51 a 100",
                                                  "100 a 200",
                                                  "200 a 300",
                                                  "Mais de 300"),
                                         rigth=T,exclude=NULL, include.lowest=TRUE)

# paletas
wardpal_ssa <- colorFactor(brewer.pal(7, "Reds"),domain=factor(covid_BAIRROS_SSA$fxa_covidbairro,
                                                               levels=c("Sem Casos",
                                                                        "1 a 30",
                                                                        "31 a 50",
                                                                        "51 a 100",
                                                                        "100 a 200",
                                                                        "200 a 300",
                                                                        "Mais de 300")))

#################################################################################################################################################################
################ Value Box salvador
#################################################################################################################################################################

Total_Ssa <- dados_SSA %>% 
              summarise(total_registros= sum(total))%>%
               as.numeric()

Pct_Ssa_Ba <- (Total_Ssa/Total_Bahia)*100

N_Bairros_Ssa <- (dados_SSA %>% filter(total!=0) %>% nrow() %>% as.numeric())-1


Pct_Bairros_Ssa <- (N_Bairros_Ssa / 163) * 100

#################################################################################################################################################################
################ Ajustes adicionais
#################################################################################################################################################################

#dados para annotate gráfico predição cidacs
hoje_data <- today("GMT")
hoje <- format(hoje_data, format ="%d/%m")

#################################################################################################################################################################
################ Servidor
#################################################################################################################################################################


#server
function(input, output, session) {

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#@@@@@@@@@ Server function Bahia 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  
########## Value Box's Bahia ##########

    ## Total de casos - Bahia #
  output$CasesBahia <- renderValueBox({
    Total_Bahia %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Casos de Covid-19 na Bahia", icon = icon("diagnoses"), color = "blue")
  })
  
  ##Taxa de Prevalência BA
  output$TxPrevalenciaBA <- renderValueBox({
    round(tx_prev_ba, 2) %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Casos por 100 mil Baianos", icon = icon("users"), color = "orange")
  })
  
  ## Mortes na Bahia#
  output$MorteBahia <- renderValueBox({
    mortes_ba %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Óbitos na Bahia", icon = icon("user-times"), color = "purple")
  })
  
  ##Taxa de Letalidade BA
  output$TxletalidadeBA <- renderValueBox({
    round(tx_let_ba, 2) %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
       paste("%") %>%
      valueBox("Taxa de letalidade", icon = icon("user-minus"), color = "red")
  })
  
######### Graficos Bahia ######  
  
### diagrama situacao casos confirmados Bahia
  output$DonutsConfirmados <- renderggiraph({
    
    
    sitconfBA <- ggplot(sitconf, aes(ymax=ymax, ymin=ymin, xmax=5, xmin=4, fill=sit)) +
      geom_rect_interactive(aes(tooltip=paste0("Número de casos - ",sit,": ", format(Casos, big.mark=".", decimal.mark=","))), stat="identity", show.legend=T, color="white") +
      geom_label(aes(x=2.8, y=media, label=paste(sit, "\n", fraction)), size=4.5, 
                 fontface='bold', label.size=0, show.legend = F, vjust=0.8, fill="white", alpha=0.) +
      scale_fill_manual(values = c("#009432", "#fa163f", "#ffd31d"))+
      coord_polar(theta="y") +
      xlim(c(0, 5)) +
      theme_void() +
      labs(fill = " ")+
      theme(legend.position="bottom", legend.title = element_text(colour="Black", size=14, face="bold"), 
            legend.text = element_text (size = 14),
            legend.background = element_rect(fill="white", size=0.5, linetype="blank"))
    
    ggiraph(code ={print(sitconfBA)})#,width_svg = 7, height_svg = 6)
  })
  
  ## Gráfico EVOLUÇÃO DE CASOS ACUMULADOS
  output$CasosCovidBaAcumulado <- renderggiraph({
    
    evolucao <- ggplot(covid_BA_serie, aes(x=as.POSIXct(date)))+
      geom_ribbon(aes(ymin=0, ymax=casos), fill="#e74c3c", alpha=0.2)+
      geom_line(aes(y=casos), color = "#e74c3c", size =2)+
      labs(x="Dias da epidemia", y="Numero de casos")+
      theme_classic()+
      geom_point_interactive(aes(y=casos, size=3, tooltip = format(casos, big.mark=".", decimal.mark=",")),color ="#e74c3c")+
      theme(legend.position = "none", axis.title.x = element_text(colour = "black", size = 12, face="bold"),
            axis.title.y = element_text(colour = "black"),
            axis.text.y = element_text(face="bold", color="#000000"),
            axis.text.x = element_text(face="bold", color="#000000"))
    
    ggiraph(code ={print(evolucao)})#,width_svg = 7, height_svg = 6)
    
  })
  

   ## Sexo dos infectados na Bahia
  output$genero_bahia <- renderPlot({ 
    ggplot(covid_BA_Sexo,aes(x="", y=Percentual, fill=Sexo)) +
      geom_bar(width=1, stat = "identity", color = "white") +
      coord_polar("y", start=0) +
      geom_text(aes(y=yposicao_legenda, label = sort(paste0(round(Percentual,2),"%"))), size = 6,
                color = 'black',fontface='bold') +
      scale_fill_manual(values = c("#ffd32a","#747d8c"))+
      labs(x="",y="") +
      theme_minimal() +
      theme_void() +
      theme(legend.position="bottom", legend.title = element_text(colour="Black", size=14, face="bold"), 
            legend.text = element_text (size = 14),
            legend.background = element_rect(fill="white", size=0.5, linetype="blank"))+
      theme(plot.title = element_text(hjust = 0.5),
            axis.text.x = element_blank(), plot.caption = element_text(hjust = 1.5))
    
  })
  
  ## Faixa Etaria dos infectados na Bahia
  output$FxEtaria_Bahia <- renderPlot({
    
    ggplot(covid_BA_FxEtaria) + 
      geom_col(aes(x=FaixaEtaria,y=Percentual), show.legend = FALSE, fill="#1abc9c",width = 0.7) +
      geom_text(aes(x=FaixaEtaria,y=Percentual,label=paste0(round(Percentual,2),"%")), position=position_dodge(width=0.9),
                vjust=-0.25, size=4, fontface='bold') +
      labs(x = "Faixa Etária (em anos)", y = "Percentual de infectados por COVID") +
      theme_classic()+
      theme(axis.title.x = element_text(colour = "black", size = 12, face="bold"),
            axis.title.y = element_text(colour = "black", size = 12),
            axis.text.y = element_text(face="bold", color="#000000", 
                                       size=7),
            plot.title = element_text(colour = "black", size = 12, hjust=0.5),
            axis.text.x = element_text(face="bold", color="#000000",size=9,vjust =0.5,angle = 45),
            plot.caption = element_text(size=10)) +
      scale_x_discrete(labels = legenda_fxaetaria)
  })
  
  ## gráfico isolamento Bahia
  
  output$EvolucaoIsolamento <- renderggiraph({
    
    isolamento_dias<- ggplot(IsolaBA, aes(y=isolated, x=as.POSIXct(date), color=isolated))+
      geom_line(size =2)+
      labs(x="Data", y="Índice de Isolamento Social")+
      scale_colour_gradient2(low = "#E91E63", mid = "#FF9800" , high = "#FFC107", 
                             midpoint=40)+ 
      ylim(c(0,100))+
      theme_classic()+
      geom_point_interactive(aes(y=isolated, tooltip = paste0("Data: ",format(date, format="%d/%m"), "\n Índice: ",isolated,"%")),size=2.6)+
      #########################################################################################################
      geom_vline(xintercept = as.numeric(as.POSIXct("2020-03-16")), size=1.3, alpha=0.7)+
      annotate_interactive(geom="label", x=as.POSIXct("2020-03-6"), y=95, label="Decreto Estadual \nnº 19.529 de\n16 de março", fill= "#f0f0f0", 
                           tooltip="Decreto  Estadual nº 19.528 - \nRegulamenta, no Estado da Bahia, as medidas temporárias \npara enfrentamento da emergência de saúde pública \nde importância internacional decorrente do coronavírus.")+
      annotate(geom = "curve", x=as.POSIXct("2020-03-8"), y=87, xend=as.POSIXct("2020-03-15"), yend =80,
               curvature=0.3, arrow=arrow(length = unit(2,"mm")))+
      annotate("text", x =as.POSIXct("2020-02-8") , y = 52, alpha = 0.35, label = "Índice mínimo recomendado", size=3) +
      geom_hline(yintercept = 50, alpha = 0.5)+
      #########################################################################################################
      theme(legend.position = "none", axis.title.x = element_text(colour = "black", size = 12, face="bold"),
            axis.title.y = element_text(colour = "black", size = 12),
            axis.text.y = element_text(face="bold", color="#000000", 
                                       size=12),
            axis.text.x = element_text(face="bold", color="#000000",size=12))
    
    ggiraph(code ={print(isolamento_dias)},width_svg = 10, height_svg = 9)
    
  })
    ## comorbidades 
  output$comorbidades <- renderPlot({ 
    
    ggplot(comorbidades_dt, aes(x=reorder(comorbidades, +vitimas)))+
      geom_col(aes(y=vitimas), fill="#e1b12c")+
      coord_flip()+
      theme_classic()+
      labs(x="", y="Número de Óbitos")+
      geom_text(aes(y=vitimas, label=vitimas), hjust = -0.3, size=4.5, fontface='bold', colour = "#000000")+
      scale_y_continuous(limits = c(0, 450))+
      theme(axis.text.y=element_text(size=8), axis.text.x = element_text(size=10))
    
  })
  
  ## Faixa Etaria dos Obitos por Covid-19 na Bahia
  output$FxEtaria_Obitos <- renderPlot({
    
    ggplot(Obitos_FxEtaria) + 
      geom_col(aes(x=FaixaEtaria,y=Percentual), show.legend = FALSE, fill="#40739e",width = 0.7) +
      geom_text(aes(x=FaixaEtaria,y=Percentual,label=paste0(round(Percentual,2),"%")), position=position_dodge(width=0.9),
                vjust=-0.25, size=4, fontface='bold') +
      labs(x = "Faixa Etária (em anos)", y = "Percentual de infectados por COVID") +
      theme_classic()+
      theme(axis.title.x = element_text(colour = "black", size = 12, face="bold"),
            axis.title.y = element_text(colour = "black", size = 12),
            axis.text.y = element_text(face="bold", color="#000000", 
                                       size=7),
            plot.title = element_text(colour = "black", size = 12, hjust=0.5),
            axis.text.x = element_text(face="bold", color="#000000",size=9,vjust =0.5,angle = 45),
            plot.caption = element_text(size=10)) +
      scale_x_discrete(labels = legenda_fxaetaria)
  })
  
  ### Gráficos barras de Leitos
  output$LeitosBA <- renderggiraph({ 
    LeitosBA_Graph <- ggplot(LeitosBA, aes(x = tipo, y = count)) + 
      geom_bar_interactive(aes(fill = situacao, tooltip=paste0(round(percent*100,1), "% \ndos leitos ", situacao)),stat = "identity", color="white")+
      theme_classic()+
      labs(x="Tipo de leito", y="Número de leitos")+
      geom_text(aes(label = count), position = position_stack(vjust = 0.5), size=4.5, fontface="bold")+
      scale_fill_manual(name="Situação dos leitos",values=c("#F57C00", "#0097e6"))+
      theme(legend.position="bottom", legend.title = element_text(colour="Black", size=12, face="bold"), 
            legend.text = element_text (size = 12),
            legend.background = element_rect(fill="white", size=0.5, linetype="blank"),
            axis.title.x = element_text(colour = "black", size = 12, face="bold"),
            axis.title.y = element_text(colour = "black", size = 12),
            axis.text.y = element_text(face="bold", color="#000000", 
                                       size=12),
            plot.title = element_text(colour = "black", size = 12, hjust=0.5),
            axis.text.x = element_text(face="bold", color="#000000",size=12))
    ggiraph(code ={print(LeitosBA_Graph)},width_svg = 9, height_svg = 6.7)
  })
  
  ################## Mapa Casos BAHIA #######################

  output$mapa_bahia <- renderLeaflet({
    leaflet(covid_map,
            options = leafletOptions(zoomControl = FALSE,
                                     minZoom = 5.5, maxZoom = 7.5, 
                                     dragging = TRUE,
                                     doubleClickZoom=FALSE)
    ) %>%
      addTiles() %>%
      #addProviderTiles("CartoDB.PositronNoLabels") %>%
      setView(lat = -13.800000, lng = -41.559343, zoom = 5.5) %>% 
      addPolygons(stroke = T,opacity = 1, color = "black",weight = 0.5, smoothFactor = 0.0, fillOpacity = 1,
                  fillColor = ~wardpal_mun(fxa_covid),
                  label = ~paste0(NM_MUNICIP, ": ",format(Casos, big.mark = ".",decimal.mark=",") ,
                                  " casos registrados")) %>%
      addLegend("bottomleft", opacity = 1,
                title = "Casos de Covid-19", pal=wardpal_mun, values = ~fxa_covid)
  })

  ################## tabela Bahia #######################
  
  output$TabPorCidade <- renderDT({
    datatable(head(covid_BA_cases,417),
              escape = FALSE,
              filter = "none",
              rownames = F ,
              colnames = c("Cidade", "Infectados", "Prevalência**", "Mortes", "Letalidade"),
              options = list(searching = FALSE,
                             paging = FALSE,
                             lengthChange = FALSE, 
                             pageLength = 10, autoWidth = T,
                             scrollX = TRUE,
                             columnDefs = list(list(className = 'dt-center', D = "_all")),
                             language = list(info ="",
                                             paginate = 
                                               list('next'="Próxima", 
                                                    previous="Voltar")))) %>%
      formatStyle('NM_MUNICIP',  color = 'black') %>%
      formatStyle('Casos',  color = 'black') %>%
      formatStyle('Prevalencia_casos',  color = 'black') %>%
      formatStyle('Obitos',  color = styleInterval(c(1, 1), c('black','red',"red"))) %>%
      formatStyle('Letalidade',  color = 'black')
    
  })
  ################## Mapa Leitos BAHIA #######################
  
  output$mapa_leitos <- renderLeaflet({
    leaflet(LeitosReferencia) %>%
      addTiles() %>%
      #addProviderTiles("CartoDB.Positron") %>%
      setView(lat = -13.800000, lng = -41.559343, zoom = 5.5) %>% 
      addMarkers(lng = ~Long, lat = ~Lat,
                 popup = ~paste0("<b>",LeitosReferencia$NOME_HOSPITAL,'</b>',"<br>",
                                 LeitosReferencia$NM_MUNICIP,"<br>", 
                                 LeitosReferencia$LeitosClinicos_DISPONIVEIS," Leitos Clínicos", "<br>",
                                 LeitosReferencia$LeitosPed_DISPONIVEIS," Leitos Pediátricos", "<br>",
                                 LeitosReferencia$Leitos_Adulto_UTI_DISPONIVEIS, " Leitos de UTI Adulto", "<br>",
                                 LeitosReferencia$Leitos_Ped_UTI_DISPONIVEIS, " Leitos de UTI Pediátrico")) 
  })
  
  ############ MAPA Isolamento municípios ##########
  
  output$mapa_isol <- renderLeaflet({
    leaflet(covid_map,
            options = leafletOptions(zoomControl = FALSE,
                                     minZoom = 5.5, maxZoom = 7.5, 
                                     dragging = TRUE,
                                     doubleClickZoom=FALSE)
    ) %>%
      addTiles() %>%
      #addProviderTiles("CartoDB.PositronNoLabels") %>%
      setView(lat = -13.800000, lng = -41.559343, zoom = 5.5) %>% 
      addPolygons(stroke = T,opacity = 1, color = "black",weight = 0.5, smoothFactor = 0.0, fillOpacity = 1,
                  label = ~paste0(NM_MUNICIP, ": ",Isolated_city,"%"), fillColor = ~wardpal_isola(fxa_isolamento),
                  highlight = highlightOptions(weight = 2,
                                               color = "black",
                                               fillOpacity = 1,
                                               bringToFront = TRUE),layerId = ~NM_MUNICIP) %>%
      addLegend("bottomleft", opacity = 1,
                title = "Isolamento Social", pal=wardpal_isola, values = c("Sem Informação",
                                                                                       "0% a 20%",
                                                                                       "20% a 30%",
                                                                                       "30% a 40%",
                                                                                       "40% a 50%",                                                                                 "50% a 60%",
                                                                                       "60% a 70%",
                                                                                       "70% a 80%",
                                                                                       "mais de 80%"))
  })
  
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#@@@@@@@@@ Server function NOrdeste 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  
  ######### Value Boxs's Nordeste #########
  
  ## Total de casos - NE 
  output$CasesNE <- renderValueBox({
    numero_casos_NE %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Casos de Covid-19 no Nordeste", icon = icon("diagnoses"), color = "blue")
    
  })
  
  ## Taxa de Prevalência NE
  output$TxPrevalenciaNE <- renderValueBox({
    round(tx_prev_NE, 2) %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Casos por 100 mil Nordestinos", icon = icon("users"), color = "orange")
  })
  
  ## Mortes no NE 
  output$MorteNE <- renderValueBox({
    mortes_NE %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Óbitos no Nordeste", icon = icon("user-times"), color = "purple")
  })
  
  ## Taxa de Letalidade NE
  output$TxletalidadeNE <- renderValueBox({
    round(tx_let_NE, 2) %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      paste("%") %>%
      valueBox("Taxa de letalidade", icon = icon("user-minus"), color = "red")
  })
  #### MAPA NORDESTE ###
  output$mapa_NE <- renderLeaflet({
    leaflet(covid_NE,
            options = leafletOptions(zoomControl = FALSE,
                                     minZoom = 5, maxZoom = 5.5, 
                                     dragging = TRUE,
                                     doubleClickZoom=FALSE)
    ) %>%
      addTiles() %>%
      #addProviderTiles("CartoDB.PositronNoLabels") %>%
      setView(lat = -10.000000, lng = -43.00000, zoom = 5) %>% 
      addPolygons(stroke = T,opacity = 1, color = "black",weight = 0.8, smoothFactor = 0.0, fillOpacity = 1,
                  fillColor = ~wardpal2(categorica),
                  label = ~paste0(NM_ESTADO, ": ",
                                  format(totalCases, big.mark = ".",decimal.mark=","),
                                  " casos registrados")) %>%
      addLegend("bottomleft",pal = wardpal2, values = ~categorica, opacity = 1.0, title = "Casos de Covid-19")
  })


##### tabela Nordeste #####
output$TabPorEstadoNE <- renderDT({
datatable(head(covid_nordeste,200),
          escape = FALSE,
          filter = "none",
          rownames = F ,
          colnames = c("Estado", "Infectados", "Prevalência**", "Mortes", "Letalidade"),
          options = list(searching = FALSE,
                         lengthChange = FALSE,
                         scrollX = TRUE,
                         pageLength = 10, autoWidth = T, 
                         columnDefs = list(list(className = 'dt-center', D = "_all")),
                         language = list(info =""),paging = FALSE)) %>%
  formatStyle('estado',  color = 'black') %>%
  formatStyle('totalCases',  color = 'black') %>%
  formatStyle('Prevalencia',  color = 'black') %>%
  formatStyle('deaths',  color = styleInterval(c(1, 1), c('black','red',"red"))) %>%
  formatStyle('Letalidade',  color = 'black') %>%
  formatRound('Prevalencia',digits = 2)

})

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#@@@@@@@@@ Server function Brasil
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  
  ########## Value Box's Brasil ##########
  
  #totalBrasil2
  output$CasesBrasil2 <- renderValueBox({
    numero_casos_br %>% format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Casos de Covid-19 no Brasil", icon = icon("hospital"), color = "blue")
  })
  
  ## Taxa de Prevalência BR
  output$TxPrevalenciaBR <- renderValueBox({
    round(tx_prev_br,2) %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Casos por 100 mil Brasileiros", icon = icon("users"), color = "orange")
  })
  
  ## Mortes no Brasil
  output$MorteBrasil <- renderValueBox({
    numero_mortes_br %>% format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Óbitos no Brasil", icon = icon("user-times"), color = "purple")
  })  
  
  ##Taxa de Letalidade BR
  output$TxletalidadeBR <- renderValueBox({
    round(tx_let_br, 2) %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      paste("%") %>%
      valueBox("Taxa de letalidade", icon = icon("user-minus"), color = "red")
  })  
  
  ####MAPA BRASIL ###
  output$mapa_br <- renderLeaflet({
    leaflet(covid_uf,
            options = leafletOptions(zoomControl = FALSE,
                                     minZoom = 4, maxZoom = 4.5, 
                                     dragging = TRUE,
                                     doubleClickZoom=FALSE)
    ) %>%
      addTiles() %>%
      #addProviderTiles("CartoDB.PositronNoLabels") %>%
      setView(lat = -13.952884, lng = -50.490640, zoom = 4) %>% 
      addPolygons(stroke = T,opacity = 1, color = "black",weight = 0.8, smoothFactor = 0.0, fillOpacity = 1,
                  fillColor = ~wardpal2(categorica),
                  label = ~paste0(NM_ESTADO, ": ",
                                  format(totalCases, big.mark = ".",decimal.mark=","),
                                  " casos registrados")) %>%
      addLegend("bottomleft",pal = wardpal2, values = ~categorica, opacity = 1.0, title = "Casos de Covid-19")
  })
  
  ########### tabela com Estados ###########
  
  output$TabPorEstado <- renderDT({
    datatable(head(covid_estados,200),
              escape = FALSE,
              filter = "none",
              rownames = F ,
              colnames = c("Estado", "Infectados", "Prevalência**", "Mortes", "Letalidade"),
              options = list(searching = FALSE,
                             paging = FALSE,
                             lengthChange = FALSE, 
                             pageLength = 10, autoWidth = T,
                             scrollX = TRUE,
                             columnDefs = list(list(className = 'dt-center', D = "_all")),
                             language = list(info ="",
                                             paginate = 
                                               list('next'="Próxima", 
                                                    previous="Voltar")))) %>%
      formatStyle('estado',  color = 'black') %>%
      formatStyle('totalCases',  color = 'black') %>%
      formatStyle('Prevalencia',  color = 'black') %>%
      formatStyle('deaths',  color = styleInterval(c(1, 1), c('black','red',"red"))) %>%
      formatStyle('Letalidade',  color = 'black') %>%
      formatRound('Prevalencia',digits = 2)
    
  })
  
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#@@@@@@@@@ Server function Salvador 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  
  ########## Value Box's Salvador ##########
  
  ## Total de casos - Salvador #
  output$CasesSSA <- renderValueBox({
    Total_Ssa %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      valueBox("Casos de Covid-19 em Salvador", icon = icon("diagnoses"), color = "blue")
  })
  
  ##Percentagem em relacao à Bahia
  output$PctSsaBa <- renderValueBox({
    round(Pct_Ssa_Ba, 2) %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      paste("%") %>%
      valueBox("do total de Infectados da Bahia", icon = icon("users"), color = "orange")
  })
  
  ##Percentagem de Bairros
  output$PctBairrosSsa <- renderValueBox({
    round(Pct_Bairros_Ssa, 2) %>%
      format(nsmall = 0 ,big.mark=".", decimal.mark=",") %>%
      paste("%") %>%
      valueBox("dos 163 bairros tem casos de Covid-19", icon = icon("map-marker"), color = "green")
  })
  
  ########### Mapa Salvador 
  
  output$mapa_ssa <- renderLeaflet({
    leaflet(covid_BAIRROS_SSA,
            options = leafletOptions(zoomControl = FALSE,
                                     minZoom = 10, maxZoom = 12, 
                                     dragging = TRUE,
                                     doubleClickZoom=FALSE)
    ) %>%
      addTiles()%>%
      #addProviderTiles("CartoDB.PositronNoLabels") %>%
      setView(lat = -12.916654, lng = -38.441899, zoom = 11) %>% 
      addPolygons(stroke = T,opacity = 1, color = "black",weight = 0.5, smoothFactor = 0.0, fillOpacity = 1,
                  fillColor = ~wardpal_ssa(fxa_covidbairro),
                  label = ~paste0(id, ": ",format(total, big.mark = ".",decimal.mark=",") ,
                                  " casos registrados")) %>%
      addLegend("bottomright", opacity = 1,
                title = "Casos de Covid-19", pal=wardpal_ssa, values = ~fxa_covidbairro) 
    
    
  })
  
  ######## Tabela Bairros de Salvador
  
  output$TabPorbairro <- renderDT({
    
    datatable(head(dados_SSA,200),
              escape = FALSE,
              filter = "none",
              rownames = F ,
              colnames = c("Bairro", "Infectados"),
              options = list(searching = FALSE,
                             paging = FALSE,
                             lengthChange = FALSE, 
                             pageLength = 10, autoWidth = T,
                             scrollX = TRUE,
                             columnDefs = list(list(className = 'dt-center', D = "_all")),
                             language = list(info ="",
                                             paginate = 
                                               list('next'="Próxima", 
                                                    previous="Voltar")))) %>%
      formatStyle('id',  color = 'black') %>%
      formatStyle('total',  color = 'black') 
    
  })
  
 
  
}

